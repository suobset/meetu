Bunch of screenshots to show progress and stuff for server deployment

![Screenshot 2023-05-11 235735](https://github.com/umass-cs-326-s23/326-project-repo-team-6/assets/73229775/53137d96-c395-41e4-8d44-7a9f502c68e7)

![Screenshot 2023-05-11 235748](https://github.com/umass-cs-326-s23/326-project-repo-team-6/assets/73229775/df585c0a-6de8-4857-8f5e-591b4da70db0)

https://meetu-cal.herokuapp.com/

currently not working due to git and server related issues
